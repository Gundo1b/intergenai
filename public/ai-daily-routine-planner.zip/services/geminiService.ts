import { GoogleGenAI, Type, Schema } from "@google/genai";
import { ScheduleBlock, UserSettings, BlockType, Category } from "../types";

// Initialize Gemini Client
// In a real app, ensure API_KEY is handled securely.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
const MODEL_NAME = 'gemini-2.5-flash';

// Define the schema for schedule generation to ensure strict JSON output
const scheduleSchema: Schema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      title: { type: Type.STRING },
      startTime: { type: Type.STRING, description: "HH:mm format 24h" },
      endTime: { type: Type.STRING, description: "HH:mm format 24h" },
      type: { type: Type.STRING, enum: [BlockType.FIXED, BlockType.FLEXIBLE] },
      category: { 
        type: Type.STRING, 
        enum: [Category.WORK, Category.STUDY, Category.HEALTH, Category.REST, Category.PERSONAL, Category.OTHER] 
      },
      description: { type: Type.STRING }
    },
    required: ["title", "startTime", "endTime", "type", "category"]
  }
};

export const generateDailySchedule = async (settings: UserSettings): Promise<ScheduleBlock[]> => {
  if (!process.env.API_KEY) {
    console.error("API Key missing");
    return [];
  }

  const prompt = `
    Create a highly optimized daily routine schedule based on these user settings:
    ${JSON.stringify(settings)}
    
    Rules:
    1. Respect wake and sleep times strictly.
    2. Fit meals around the preferred times.
    3. Work hours are fixed.
    4. Insert flexible tasks and breaks logically to maximize energy management.
    5. Include a specific time for Gym based on preference.
    6. Ensure the schedule is chronological from Wake to Sleep.
    7. Return ONLY the JSON array.
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: scheduleSchema,
        temperature: 0.7,
      }
    });

    const text = response.text;
    if (!text) return [];
    
    const rawBlocks = JSON.parse(text);
    // Add IDs locally
    return rawBlocks.map((b: any) => ({ ...b, id: crypto.randomUUID(), isCompleted: false }));
  } catch (error) {
    console.error("Gemini Schedule Gen Error:", error);
    return [];
  }
};

export const adjustSchedule = async (currentSchedule: ScheduleBlock[], userRequest: string, currentTime: string): Promise<ScheduleBlock[]> => {
  if (!process.env.API_KEY) return currentSchedule;

  const prompt = `
    Current Time: ${currentTime}
    User Request/Context: "${userRequest}"
    
    Existing Schedule:
    ${JSON.stringify(currentSchedule)}
    
    Task:
    Update the schedule starting from ${currentTime}. 
    1. If the user is late, shift subsequent tasks.
    2. If the user wants to move a task, move it and adjust surrounding blocks.
    3. Maintain fixed blocks (like work meetings) if possible, unless explicitly asked to move.
    4. Return the COMPLETE updated schedule for the whole day (past tasks unchanged, future tasks adjusted).
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: scheduleSchema,
      }
    });

    const text = response.text;
    if (!text) return currentSchedule;

    const rawBlocks = JSON.parse(text);
    // Preserve IDs of existing blocks where possible or assign new ones
    return rawBlocks.map((b: any) => ({ 
      ...b, 
      id: b.id || crypto.randomUUID(), 
      isCompleted: b.endTime < currentTime // Simple auto-complete logic based on time
    }));
  } catch (error) {
    console.error("Gemini Adjustment Error:", error);
    return currentSchedule;
  }
};

export const chatWithAssistant = async (history: string, message: string): Promise<string> => {
  if (!process.env.API_KEY) return "Please configure your API Key.";

  const prompt = `
    You are a helpful, motivational productivity assistant integrated into a Daily Routine Planner app.
    
    Conversation History:
    ${history}
    
    User: ${message}
    
    Reply briefly and encouragingly. If the user asks to change the schedule, confirm you can do it (the app handles the actual logic via a separate tool, but you represent the interface).
  `;

  try {
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: prompt,
    });
    return response.text || "I'm having trouble thinking right now.";
  } catch (error) {
    return "Sorry, I am offline.";
  }
};
