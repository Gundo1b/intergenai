import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { AppProvider } from './contexts/AppContext';
import { Layout } from './components/Layout';
import { Timeline } from './components/Timeline';
import { RoutineForm } from './components/RoutineForm';
import { StatsDashboard } from './components/StatsDashboard';
import { ChatAssistant } from './components/ChatAssistant';
import { MoodTracker } from './components/MoodTracker';

const Dashboard = () => (
  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <div className="lg:col-span-2">
      <Timeline />
    </div>
    <div className="space-y-8">
      <MoodTracker />
      <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100">
        <h3 className="text-indigo-900 font-bold mb-2">Productivity Tip</h3>
        <p className="text-sm text-indigo-700">
          Your energy typically dips around 2:00 PM. The AI has scheduled a lighter task during this window to keep your momentum going.
        </p>
      </div>
    </div>
  </div>
);

const App = () => {
  return (
    <AppProvider>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/setup" element={<RoutineForm />} />
          <Route path="/stats" element={<StatsDashboard />} />
        </Routes>
        <ChatAssistant />
      </Layout>
    </AppProvider>
  );
};

export default App;
