import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { UserSettings } from '../types';
import { Save, Loader2 } from 'lucide-react';

export const RoutineForm = () => {
  const { settings, updateSettings, generateNewSchedule, isLoading } = useApp();
  const [localSettings, setLocalSettings] = useState<UserSettings>(settings);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setLocalSettings(prev => ({ ...prev, [name]: value }));
  };

  const handleSaveAndGenerate = async () => {
    updateSettings(localSettings);
    await generateNewSchedule();
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Setup Your Routine</h2>
      
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Wake Up Time</label>
            <input 
                type="time" 
                name="wakeTime"
                value={localSettings.wakeTime}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Sleep Time</label>
            <input 
                type="time" 
                name="sleepTime"
                value={localSettings.sleepTime}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Work Start</label>
            <input 
                type="time" 
                name="workHoursStart"
                value={localSettings.workHoursStart}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Work End</label>
            <input 
                type="time" 
                name="workHoursEnd"
                value={localSettings.workHoursEnd}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
            />
          </div>
        </div>

        <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Gym Preference</label>
            <select 
                name="gymPreferences"
                value={localSettings.gymPreferences}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent outline-none"
            >
                <option value="Morning">Morning</option>
                <option value="Afternoon">Afternoon</option>
                <option value="Evening">Evening</option>
                <option value="Rest Day">Rest Day</option>
            </select>
        </div>

        <div className="pt-4">
            <button 
                onClick={handleSaveAndGenerate}
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-indigo-700 text-white py-3 rounded-xl font-medium transition-all shadow-lg shadow-primary/30 disabled:opacity-70 disabled:cursor-not-allowed"
            >
                {isLoading ? <Loader2 className="animate-spin w-5 h-5" /> : <Save className="w-5 h-5" />}
                {isLoading ? 'Generating Schedule...' : 'Save & Generate Schedule'}
            </button>
            <p className="text-center text-xs text-gray-400 mt-4">
                Powered by Google Gemini AI
            </p>
        </div>
      </div>
    </div>
  );
};
