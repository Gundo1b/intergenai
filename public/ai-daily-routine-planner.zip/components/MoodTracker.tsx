import React, { useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { Smile, Frown, Meh, Battery, BatteryCharging, BatteryLow } from 'lucide-react';

export const MoodTracker = () => {
  const { updateMood, dayStats } = useApp();
  const [selectedMood, setSelectedMood] = useState(dayStats.mood || 'Neutral');
  const [energy, setEnergy] = useState(dayStats.energyLevel || 5);

  const moods = [
    { label: 'Great', icon: Smile, color: 'text-green-500' },
    { label: 'Good', icon: Smile, color: 'text-blue-500' }, // Use same icon but diff color
    { label: 'Neutral', icon: Meh, color: 'text-gray-500' },
    { label: 'Tired', icon: Frown, color: 'text-orange-500' },
    { label: 'Stressed', icon: Frown, color: 'text-red-500' },
  ];

  const handleSave = () => {
    updateMood(selectedMood as any, energy);
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-bold text-gray-800">How are you feeling?</h3>
        <button onClick={handleSave} className="text-xs text-primary font-semibold hover:underline">
            Save Log
        </button>
      </div>

      <div className="flex justify-between mb-6">
        {moods.map((m) => (
            <button 
                key={m.label}
                onClick={() => setSelectedMood(m.label as any)}
                className={`flex flex-col items-center gap-1 transition-transform ${selectedMood === m.label ? 'scale-110' : 'opacity-50 hover:opacity-100'}`}
            >
                <m.icon className={`w-8 h-8 ${m.color}`} />
                <span className="text-[10px] font-medium text-gray-500">{m.label}</span>
            </button>
        ))}
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
            <Battery className="w-4 h-4" />
            <span>Energy Level: {energy}/10</span>
        </div>
        <input 
            type="range" 
            min="1" 
            max="10" 
            value={energy} 
            onChange={(e) => setEnergy(parseInt(e.target.value))}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-primary"
        />
        <div className="flex justify-between text-xs text-gray-400 px-1">
            <span>Low</span>
            <span>High</span>
        </div>
      </div>
    </div>
  );
};
