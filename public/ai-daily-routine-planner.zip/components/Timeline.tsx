import React, { useEffect, useState } from 'react';
import { useApp } from '../contexts/AppContext';
import { CheckCircle, Circle, Clock, MoreVertical, Coffee, Briefcase, Dumbbell, Moon, BookOpen } from 'lucide-react';
import { Category, ScheduleBlock } from '../types';

const getCategoryIcon = (category: Category) => {
  switch (category) {
    case Category.WORK: return Briefcase;
    case Category.REST: return Coffee;
    case Category.HEALTH: return Dumbbell; // Or Moon for sleep
    case Category.STUDY: return BookOpen;
    default: return Circle;
  }
};

const getCategoryColor = (category: Category) => {
  switch (category) {
    case Category.WORK: return 'bg-blue-100 text-blue-700 border-blue-200';
    case Category.STUDY: return 'bg-indigo-100 text-indigo-700 border-indigo-200';
    case Category.HEALTH: return 'bg-green-100 text-green-700 border-green-200';
    case Category.REST: return 'bg-orange-100 text-orange-700 border-orange-200';
    case Category.PERSONAL: return 'bg-pink-100 text-pink-700 border-pink-200';
    default: return 'bg-gray-100 text-gray-700 border-gray-200';
  }
};

export const Timeline = () => {
  const { schedule, toggleBlockCompletion, modifySchedule, isLoading } = useApp();
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 60000);
    return () => clearInterval(timer);
  }, []);

  const handleLate = () => {
    modifySchedule("I am running 30 minutes late for my current task. Push everything back.");
  };

  if (schedule.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-gray-500">
        <Clock className="w-12 h-12 mb-4 opacity-20" />
        <p>No schedule generated yet. Go to Setup!</p>
      </div>
    );
  }

  // Find current active block
  const currentBlockIndex = schedule.findIndex(block => {
    const now = currentTime.getHours() * 60 + currentTime.getMinutes();
    const [startH, startM] = block.startTime.split(':').map(Number);
    const [endH, endM] = block.endTime.split(':').map(Number);
    const startTotal = startH * 60 + startM;
    const endTotal = endH * 60 + endM;
    return now >= startTotal && now < endTotal;
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end">
        <div>
           <h2 className="text-2xl font-bold text-gray-900">Today's Schedule</h2>
           <p className="text-gray-500">{currentTime.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</p>
        </div>
        <button 
            onClick={handleLate}
            disabled={isLoading}
            className="px-4 py-2 bg-warning/10 text-warning hover:bg-warning/20 rounded-lg text-sm font-medium transition-colors disabled:opacity-50"
        >
            {isLoading ? 'Adjusting...' : 'I\'m running late (+30m)'}
        </button>
      </div>

      <div className="relative border-l-2 border-gray-200 ml-4 space-y-6">
        {schedule.map((block, index) => {
          const Icon = getCategoryIcon(block.category);
          const isCurrent = index === currentBlockIndex;
          const isPast = index < currentBlockIndex && currentBlockIndex !== -1;
          
          return (
            <div key={block.id} className={`relative pl-8 group ${isPast ? 'opacity-60' : 'opacity-100'}`}>
              {/* Timeline Connector Dot */}
              <div 
                className={`absolute -left-[9px] top-0 w-4 h-4 rounded-full border-2 ${
                  isCurrent ? 'bg-primary border-primary ring-4 ring-primary/20' : 
                  block.isCompleted ? 'bg-success border-success' : 'bg-white border-gray-300'
                } transition-all duration-300`}
              >
                 {block.isCompleted && <CheckCircle className="w-full h-full text-white p-0.5" />}
              </div>

              {/* Time */}
              <div className="absolute -left-20 top-0 text-sm font-medium text-gray-500 w-12 text-right">
                {block.startTime}
              </div>

              {/* Card */}
              <div 
                className={`
                    p-4 rounded-2xl border transition-all duration-300
                    ${isCurrent ? 'bg-white shadow-lg scale-105 border-primary/20 ring-1 ring-primary/5' : 'bg-white shadow-sm border-gray-100 hover:shadow-md'}
                `}
              >
                <div className="flex justify-between items-start">
                  <div className="flex items-start gap-3">
                    <div className={`p-2 rounded-lg ${getCategoryColor(block.category)}`}>
                        <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className={`font-semibold ${isCurrent ? 'text-xl text-primary' : 'text-lg text-gray-800'}`}>
                        {block.title}
                      </h3>
                      <p className="text-sm text-gray-500 mt-1 flex items-center gap-2">
                        <span>{block.startTime} - {block.endTime}</span>
                        <span className="w-1 h-1 rounded-full bg-gray-300"></span>
                        <span className="uppercase text-xs tracking-wider">{block.type}</span>
                      </p>
                      {block.description && (
                        <p className="text-sm text-gray-600 mt-2 bg-gray-50 p-2 rounded-md border border-gray-100">
                          {block.description}
                        </p>
                      )}
                    </div>
                  </div>
                  
                  <button 
                    onClick={() => toggleBlockCompletion(block.id)}
                    className={`p-2 rounded-full hover:bg-gray-50 transition-colors ${block.isCompleted ? 'text-success' : 'text-gray-300 hover:text-gray-500'}`}
                  >
                    {block.isCompleted ? <CheckCircle className="w-6 h-6" /> : <Circle className="w-6 h-6" />}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
