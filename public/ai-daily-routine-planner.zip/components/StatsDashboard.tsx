import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { MOCK_WEEKLY_STATS } from '../constants';
import { useApp } from '../contexts/AppContext';

export const StatsDashboard = () => {
  const { dayStats } = useApp();

  // Pie chart data from current day
  const dailyData = [
    { name: 'Work', value: dayStats.hoursWorked, color: '#4F46E5' }, // Primary
    { name: 'Rest', value: dayStats.hoursRested, color: '#F59E0B' }, // Warning
    { name: 'Sleep', value: dayStats.hoursSlept, color: '#10B981' }, // Success
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Weekly Insights</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Productivity Score Card */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center justify-center">
            <h3 className="text-gray-500 font-medium mb-2">Today's Productivity</h3>
            <div className="relative w-32 h-32 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90">
                    <circle cx="64" cy="64" r="56" stroke="#f3f4f6" strokeWidth="12" fill="transparent" />
                    <circle 
                        cx="64" cy="64" r="56" 
                        stroke="#4F46E5" strokeWidth="12" 
                        fill="transparent" 
                        strokeDasharray={351.8} 
                        strokeDashoffset={351.8 - (351.8 * dayStats.productivityScore) / 100}
                        className="transition-all duration-1000 ease-out"
                    />
                </svg>
                <span className="absolute text-3xl font-bold text-primary">{dayStats.productivityScore}%</span>
            </div>
            <p className="text-sm text-center text-gray-400 mt-2">Based on task completion</p>
        </div>

        {/* Daily Distribution */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="text-gray-500 font-medium mb-4">Time Distribution (Today)</h3>
            <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie 
                            data={dailyData} 
                            innerRadius={50} 
                            outerRadius={70} 
                            paddingAngle={5} 
                            dataKey="value"
                        >
                            {dailyData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                        </Pie>
                        <Tooltip />
                    </PieChart>
                </ResponsiveContainer>
            </div>
            <div className="flex justify-center gap-4 text-xs text-gray-500">
                {dailyData.map(d => (
                    <div key={d.name} className="flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full" style={{ backgroundColor: d.color }}></span>
                        {d.name}
                    </div>
                ))}
            </div>
        </div>

        {/* Weekly Trend */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="text-gray-500 font-medium mb-4">Weekly Balance</h3>
            <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={MOCK_WEEKLY_STATS}>
                        <XAxis dataKey="name" axisLine={false} tickLine={false} fontSize={12} />
                        <Tooltip cursor={{ fill: '#F7F9FC' }} />
                        <Bar dataKey="work" stackId="a" fill="#4F46E5" radius={[0, 0, 4, 4]} />
                        <Bar dataKey="rest" stackId="a" fill="#F59E0B" />
                        <Bar dataKey="sleep" stackId="a" fill="#10B981" radius={[4, 4, 0, 0]} />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
      </div>
    </div>
  );
};
