import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { ScheduleBlock, UserSettings, DayStats, ChatMessage } from '../types';
import { DEFAULT_SETTINGS } from '../constants';
import { generateDailySchedule, adjustSchedule, chatWithAssistant } from '../services/geminiService';

interface AppContextType {
  settings: UserSettings;
  updateSettings: (newSettings: UserSettings) => void;
  schedule: ScheduleBlock[];
  setSchedule: (schedule: ScheduleBlock[]) => void;
  generateNewSchedule: () => Promise<void>;
  modifySchedule: (instruction: string) => Promise<void>;
  toggleBlockCompletion: (id: string) => void;
  isLoading: boolean;
  dayStats: DayStats;
  updateMood: (mood: DayStats['mood'], energy: number) => void;
  chatHistory: ChatMessage[];
  sendChatMessage: (text: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [settings, setSettings] = useState<UserSettings>(() => {
    const saved = localStorage.getItem('routine_settings');
    return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
  });

  const [schedule, setSchedule] = useState<ScheduleBlock[]>(() => {
    const saved = localStorage.getItem('daily_schedule');
    return saved ? JSON.parse(saved) : [];
  });

  const [dayStats, setDayStats] = useState<DayStats>({
    date: new Date().toISOString().split('T')[0],
    hoursWorked: 0,
    hoursRested: 0,
    hoursSlept: 0,
    productivityScore: 75,
  });

  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
    { id: '1', role: 'model', text: 'Hello! I am your AI routine assistant. How can I help you plan your day?', timestamp: Date.now() }
  ]);

  const [isLoading, setIsLoading] = useState(false);

  // Persistence
  useEffect(() => {
    localStorage.setItem('routine_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('daily_schedule', JSON.stringify(schedule));
    // Calculate stats when schedule changes
    calculateStats();
     // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [schedule]);

  const updateSettings = (newSettings: UserSettings) => {
    setSettings(newSettings);
  };

  const generateNewSchedule = async () => {
    setIsLoading(true);
    const newSchedule = await generateDailySchedule(settings);
    setSchedule(newSchedule);
    setIsLoading(false);
  };

  const modifySchedule = async (instruction: string) => {
    setIsLoading(true);
    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    const updated = await adjustSchedule(schedule, instruction, currentTime);
    setSchedule(updated);
    setIsLoading(false);
  };

  const toggleBlockCompletion = (id: string) => {
    setSchedule(prev => prev.map(block => 
      block.id === id ? { ...block, isCompleted: !block.isCompleted } : block
    ));
  };

  const updateMood = (mood: DayStats['mood'], energy: number) => {
    setDayStats(prev => ({ ...prev, mood, energyLevel: energy }));
  };

  const sendChatMessage = async (text: string) => {
    const userMsg: ChatMessage = { id: crypto.randomUUID(), role: 'user', text, timestamp: Date.now() };
    setChatHistory(prev => [...prev, userMsg]);
    
    // Check if message is a command
    const lower = text.toLowerCase();
    if (lower.includes('reschedule') || lower.includes('move') || lower.includes('add') || lower.includes('delete') || lower.includes('late')) {
        await modifySchedule(text);
        const sysMsg: ChatMessage = { id: crypto.randomUUID(), role: 'model', text: "I've updated your schedule based on your request.", timestamp: Date.now() };
        setChatHistory(prev => [...prev, sysMsg]);
    } else {
        const historyText = chatHistory.map(m => `${m.role}: ${m.text}`).join('\n');
        const response = await chatWithAssistant(historyText, text);
        const aiMsg: ChatMessage = { id: crypto.randomUUID(), role: 'model', text: response, timestamp: Date.now() };
        setChatHistory(prev => [...prev, aiMsg]);
    }
  };

  const calculateStats = () => {
     // Simple calculation logic
     let work = 0;
     let rest = 0;
     let sleep = 0;
     
     schedule.forEach(block => {
        const start = parseInt(block.startTime.split(':')[0]) + parseInt(block.startTime.split(':')[1])/60;
        const end = parseInt(block.endTime.split(':')[0]) + parseInt(block.endTime.split(':')[1])/60;
        let duration = end - start;
        if (duration < 0) duration += 24; // Handle midnight crossing

        if (block.category === 'WORK' || block.category === 'STUDY') work += duration;
        else if (block.category === 'REST' || block.category === 'PERSONAL') rest += duration;
        else if (block.category === 'HEALTH' && block.title.toLowerCase().includes('sleep')) sleep += duration;
     });

     setDayStats(prev => ({
         ...prev,
         hoursWorked: parseFloat(work.toFixed(1)),
         hoursRested: parseFloat(rest.toFixed(1)),
         hoursSlept: parseFloat(sleep.toFixed(1))
     }));
  };

  return (
    <AppContext.Provider value={{
      settings,
      updateSettings,
      schedule,
      setSchedule,
      generateNewSchedule,
      modifySchedule,
      toggleBlockCompletion,
      isLoading,
      dayStats,
      updateMood,
      chatHistory,
      sendChatMessage
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
