export enum BlockType {
  FIXED = 'FIXED',
  FLEXIBLE = 'FLEXIBLE',
}

export enum Category {
  WORK = 'WORK',
  STUDY = 'STUDY',
  HEALTH = 'HEALTH', // Gym, Eat, Sleep
  REST = 'REST',
  PERSONAL = 'PERSONAL',
  OTHER = 'OTHER'
}

export interface ScheduleBlock {
  id: string;
  title: string;
  startTime: string; // Format "HH:mm"
  endTime: string;   // Format "HH:mm"
  type: BlockType;
  category: Category;
  description?: string;
  isCompleted: boolean;
}

export interface UserSettings {
  wakeTime: string;
  sleepTime: string;
  workHoursStart: string;
  workHoursEnd: string;
  mealTimes: string[]; // ["08:00", "12:00", "19:00"]
  gymPreferences: string;
  flexibleTasks: string[]; // ["Read book", "Meditate"]
}

export interface DayStats {
  date: string;
  hoursWorked: number;
  hoursRested: number;
  hoursSlept: number;
  productivityScore: number; // 0-100
  mood?: 'Great' | 'Good' | 'Neutral' | 'Tired' | 'Stressed';
  energyLevel?: number; // 1-10
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}
