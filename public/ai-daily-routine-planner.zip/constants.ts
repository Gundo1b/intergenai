import { UserSettings } from './types';

export const DEFAULT_SETTINGS: UserSettings = {
  wakeTime: "07:00",
  sleepTime: "23:00",
  workHoursStart: "09:00",
  workHoursEnd: "17:00",
  mealTimes: ["08:00", "12:30", "19:00"],
  gymPreferences: "Morning",
  flexibleTasks: ["Meditation", "Reading"],
};

export const MOCK_WEEKLY_STATS = [
  { name: 'Mon', work: 7, rest: 3, sleep: 7.5 },
  { name: 'Tue', work: 8, rest: 2, sleep: 7 },
  { name: 'Wed', work: 6.5, rest: 4, sleep: 8 },
  { name: 'Thu', work: 9, rest: 1.5, sleep: 6.5 },
  { name: 'Fri', work: 7, rest: 3, sleep: 7 },
  { name: 'Sat', work: 2, rest: 8, sleep: 9 },
  { name: 'Sun', work: 1, rest: 9, sleep: 9 },
];
